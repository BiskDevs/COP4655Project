//
//  ContentView.swift
//  ESP8266LED
//
//  Created by Ivan Rios on 6/12/24.
//

import SwiftUI
import UIKit
import WebKit


struct ContentView: View {
    
    var urlreq: URL?
    @State var tempInt: Int? = 0
    @State var bulbImg: String = "bulbOn"
    @State var buttonState: String = "onBtn"
    @State private var fadeOut = false
    
    var body: some View {
        ZStack {
//            Color.gray
            
            
            
//            Butt
            
            Spacer()
            VStack {
                Spacer()
                Image(bulbImg)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300)
                  
                
                Spacer()
                HStack{
                    Spacer()
                    Button(action: {
                        if (tempInt == 0){
                            tempInt = 1
                            bulbImg = "bulbOn"
                            buttonState = "onBtn"
                        }else if (tempInt == 1){
                            tempInt = 0
                            bulbImg = "bulbOff"
                            buttonState = "offBtn"
                        }
                        
                    }, label: {
                        Image(buttonState)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 150)
                            .clipShape(Circle())
                            .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                        
                    })
                    Spacer()
                    
                }
                .padding()
                
                Spacer()
                
                HStack{
                    WebView(temp: tempInt)
                    
                }
                Spacer()
            }
        }
    }
}
#Preview {
    ContentView()
}

struct WebView: UIViewRepresentable{

    var temp: Int?
    
    func makeUIView(context: Context) -> WKWebView{
        return WKWebView()
    }
    
    func updateUIView(_ webView: WKWebView, context: Context){
  
        var tempUrl: String = ""

       
        if(temp == 1)    {
            tempUrl =  "http://10.0.0.158/led/1"
        }else if (temp == 0){
            tempUrl =  "http://10.0.0.158/led/0"
        }

        let url = URL(string: tempUrl)
       
        if let url = url {
            let request = URLRequest(url: url)
            webView.load(request)

        }
    }
}


