//
//  ESP8266LEDApp.swift
//  ESP8266LED
//
//  Created by Ivan Rios on 6/12/24.
//

import SwiftUI

@main
struct ESP8266LEDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
